//Employee model is equivalent to User
export class Employee {

    id: string;
    name: string;
    proficiency: string;
  }